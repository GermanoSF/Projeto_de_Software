package com.example.demo.controller;

import com.example.demo.model.Categoria;
import com.example.demo.service.CategoriaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
@RequestMapping("/categoria")
public class CategoriaController {

    @Autowired
    private CategoriaService categoriaService;

    @GetMapping("/editar/{nome}")
    public String editar(@PathVariable("nome") String nome,Model model) {

        Categoria categoria = categoriaService.procurarPorNome(nome);
//        if (categoria != null) {

            model.addAttribute("categoria", categoria);
            return "formularioCategoria";

//        }

//        model.addAttribute("erroEdicaoCategoria", true);
//        return "redirect:/catregoria/listar";

    }

    @GetMapping("/deletar/{nome}")
    public String editar(@PathVariable("nome") String nome,RedirectAttributes attributes) {

        if (categoriaService.deletarPorNome(nome)) {

            attributes.addFlashAttribute("sucessoDelecao", true);
            return "redirect:/categoria/listar";

        }

//        attributes.addFlashAttribute("falhaDelecao", true);
        return "redirect:/catregoria/listar";

    }

    @GetMapping("/formulario")
    public String formulario(Model model){

        model.addAttribute("categoria", new Categoria());
        return "formularioCategoria";

    }

    @GetMapping("/listar")
    public String listarCategorias(Model model){

        List<Categoria> categorias = categoriaService.encontrarTodos();

        if (!categorias.isEmpty()) {
            model.addAttribute("categorias", categorias);
            return "listaCategorias";
        }

        model.addAttribute("categoria", new Categoria());
        model.addAttribute("erroListarCategorias", true);
        return "formularioCategoria";

    }

    @PostMapping("/salvar")
    public String salvar(@ModelAttribute Categoria categoria, RedirectAttributes attributes){

        if (categoriaService.salvar(categoria)){

            attributes.addFlashAttribute("categoriaSalva", true);
            return "redirect:/categoria/listar";

        }

        attributes.addFlashAttribute("erroSalvarCategoria", true);
        return "redirect:/categoria/listar";

    }

}
