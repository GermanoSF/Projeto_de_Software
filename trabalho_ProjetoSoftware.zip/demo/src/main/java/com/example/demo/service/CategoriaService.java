package com.example.demo.service;

import com.example.demo.model.Categoria;
import com.example.demo.repository.CategoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CategoriaService {

    @Autowired
    private CategoriaRepository categoriaRepository;

    public Categoria procurarPorNome(String nome) {

        Optional<Categoria> categoria = categoriaRepository.findByNome(nome);

        return categoria.orElse(null);

    }

    public boolean deletarPorNome(String nome) {

        Integer numeroDelecoes = categoriaRepository.deleteByNome(nome);

        if (numeroDelecoes > 0) {

            return true;

        }

        return false;

    }

    public List<Categoria> encontrarTodos() {

        List<Categoria> categorias = categoriaRepository.findAll();

        return categorias;

    }

    public boolean salvar(Categoria categoria) {

        if (categoriaRepository.save(categoria).getId() != null) {

            return true;

        }

        return false;

    }

}
