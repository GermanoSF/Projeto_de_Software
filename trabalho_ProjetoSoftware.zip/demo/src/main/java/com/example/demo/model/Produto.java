package com.example.demo.model;

import jakarta.persistence.*;

@Entity
public class Produto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(unique=true,nullable = false,length = 100)
    private String nome;

    @Column(length = 100)
    private String descricao;

    private int quantidade;

    private double valor;

    @ManyToOne
    @JoinColumn(name = "categoriaId")
    private Categoria categoria;

    private String imagem;

    public Produto(Integer id, String nome, String descricao, int quantidade, double valor, Categoria categoria, String imagem) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.valor = valor;
        this.categoria = categoria;
        this.imagem = imagem;
    }

    public Produto(String nome, String descricao, int quantidade, double valor, Categoria categoria, String imagem) {
        this.nome = nome;
        this.descricao = descricao;
        this.quantidade = quantidade;
        this.valor = valor;
        this.categoria = categoria;
        this.imagem = imagem;
    }

    public Produto() {}

    public Integer getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getDescricao() {
        return descricao;
    }

    public int getQuantidade() {
        return quantidade;
    }

    public double getValor() {
        return valor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public String getImagem() {
        return imagem;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public void setQuantidade(int quantidade) {
        this.quantidade = quantidade;
    }

    public void setValor(double valor) {
        this.valor = valor;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public void setImagem(String imagem) {
        this.imagem = imagem;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    //    @Override
//    public String toString() {
//        return "Produto{" +
//                "id=" + id +
//                ", nome='" + nome + '\'' +
//                ", descricao='" + descricao + '\'' +
//                ", quantidade=" + quantidade +
//                ", valor=" + valor +
//                ", imagem=" + imagem +
//                '}';
//    }

}
