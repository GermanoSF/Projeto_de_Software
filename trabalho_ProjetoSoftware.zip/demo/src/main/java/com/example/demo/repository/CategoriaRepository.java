package com.example.demo.repository;

import com.example.demo.model.Categoria;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CategoriaRepository extends JpaRepository<Categoria,Integer> {

    Optional<Categoria> findByNome(String nome);

    @Transactional
    Integer deleteByNome(String nome);

}
